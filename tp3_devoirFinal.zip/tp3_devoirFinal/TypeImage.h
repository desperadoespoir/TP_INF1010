#ifndef TP3_TYPE_IMAGE_H
#define TP3_TYPE_IMAGE_H

// Enumeration definissant les types d'images possibles
enum TypeImage {
	NB, Gris, Couleurs
};

#endif // TP3_TYPE_IMAGE_H