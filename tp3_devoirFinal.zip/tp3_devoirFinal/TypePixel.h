#ifndef TP3_TYPE_PIXEL_H
#define TP3_TYPE_PIXEL_H

// Enumeration definissant les types de Pixels possibles
enum TypePixel {
	NoireBlanc, NuanceDeGris, Couleur
};

#endif // TP3_TYPE_PIXEL_H